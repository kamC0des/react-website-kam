import React from 'react'
import '../../App.css'

export default function Projects(){
    return <h1 className='projects'>Projects</h1>;
}