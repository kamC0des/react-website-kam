import React from 'react';
import '../../App.css';

export default function AboutMe(){
    return <h1 className='aboutme'>My Story</h1>
}